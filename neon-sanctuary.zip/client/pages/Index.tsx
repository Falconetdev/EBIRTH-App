import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Clock, Phone } from "lucide-react";

export default function Index() {
  return (
    <div className="min-h-screen bg-[#1a0b2e]">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-purple-800/20 to-transparent"></div>
        
        {/* Decorative Coins */}
        <div className="absolute top-20 left-10 w-32 h-32 opacity-30">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 animate-pulse"></div>
        </div>
        <div className="absolute bottom-20 right-10 w-40 h-40 opacity-20">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 animate-pulse delay-150"></div>
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
                <span className="text-[#FFD700]">sBirth</span>
                <br />
                Business Academy
              </h1>
              <p className="text-white/80 text-lg mb-8 max-w-xl">
                Learn Crypto Trading and Business online from basic to advanced techniques. Master the art of crypto currency and build your digital empire.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold px-8 py-6 text-lg rounded-lg">
                  Join 35,000
                </Button>
                <Button variant="outline" className="border-2 border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black font-semibold px-8 py-6 text-lg rounded-lg bg-transparent">
                  Know More
                </Button>
              </div>

              {/* Stats Badges */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
                <div className="bg-purple-900/40 backdrop-blur-sm border border-purple-700/30 rounded-lg p-3 text-center">
                  <p className="text-[#FFD700] font-bold text-xs uppercase">Practical</p>
                  <p className="text-white text-xs">Resources</p>
                </div>
                <div className="bg-purple-900/40 backdrop-blur-sm border border-purple-700/30 rounded-lg p-3 text-center">
                  <p className="text-[#FFD700] font-bold text-xs uppercase">Expert</p>
                  <p className="text-white text-xs">Instructors</p>
                </div>
                <div className="bg-purple-900/40 backdrop-blur-sm border border-purple-700/30 rounded-lg p-3 text-center">
                  <p className="text-[#FFD700] font-bold text-xs uppercase">Flexible</p>
                  <p className="text-white text-xs">Courses</p>
                </div>
                <div className="bg-purple-900/40 backdrop-blur-sm border border-purple-700/30 rounded-lg p-3 text-center">
                  <p className="text-[#FFD700] font-bold text-xs uppercase">Career</p>
                  <p className="text-white text-xs">Support</p>
                </div>
              </div>
            </div>

            {/* Right - Decorative Image Placeholder */}
            <div className="relative hidden lg:block">
              <div className="w-full h-[500px] relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-purple-900/40 rounded-3xl backdrop-blur-sm border border-purple-500/30 flex items-center justify-center">
                  <div className="w-48 h-48 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 opacity-50 animate-pulse"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-900/30 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <h3 className="text-4xl md:text-5xl font-bold text-[#FFD700] mb-2">305+</h3>
              <p className="text-white/70">Expert Mentors</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl md:text-5xl font-bold text-[#FFD700] mb-2">3,600+</h3>
              <p className="text-white/70">Students Enrolled</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl md:text-5xl font-bold text-[#FFD700] mb-2">220+</h3>
              <p className="text-white/70">Premium Courses</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl md:text-5xl font-bold text-[#FFD700] mb-2">1,700+</h3>
              <p className="text-white/70">Success Stories</p>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Are Section */}
      <section id="who-we-are" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-transparent to-purple-800/20"></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Image */}
            <div className="relative">
              <div className="aspect-[4/3] bg-gradient-to-br from-purple-600/30 to-purple-900/50 rounded-3xl backdrop-blur-sm border border-purple-500/30 overflow-hidden">
                <img 
                  src="/placeholder.svg" 
                  alt="Students learning" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
            </div>

            {/* Right - Content */}
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Who We Are
              </h2>
              <h3 className="text-2xl md:text-3xl text-[#FFD700] mb-6">
                BUILDING BRIDGES, DISCOVERING SKILLS
              </h3>
              <p className="text-white/70 mb-8 leading-relaxed">
                Register money mind. Expert level and any money. No worries, we can do anything. You can do and get anything. It's all done professionally, and your data secure with us. It is something you seek, and your journey starts here.
              </p>
              <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold px-8 py-6 text-lg rounded-lg">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Our New Lessons Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-900/30 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Our New Lessons
            </h2>
            <p className="text-white/70 max-w-3xl mx-auto">
              Exclusively Crypto related trading for you. We prepared advanced techniques made possible
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Course Card 1 */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-red-500/30 to-red-700/50 flex items-center justify-center text-white font-bold text-2xl">
                <div className="bg-red-600/80 px-6 py-3 rounded-lg">ට්‍රේඩින්ග් 17</div>
              </div>
              <div className="p-6">
                <h3 className="text-white font-semibold text-xl mb-4">Advanced Trading Strategies</h3>
                <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold w-full rounded-lg">
                  Get Started
                </Button>
              </div>
            </Card>

            {/* Course Card 2 */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm overflow-hidden">
              <div className="aspect-video bg-gradient-to-br from-red-500/30 to-red-700/50 flex items-center justify-center text-white font-bold text-2xl">
                <div className="bg-red-600/80 px-6 py-3 rounded-lg">ට්‍රේඩින්ග් 28</div>
              </div>
              <div className="p-6">
                <h3 className="text-white font-semibold text-xl mb-4">Master Crypto Analysis</h3>
                <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold w-full rounded-lg">
                  Get Started
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* WhatsApp Banner */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-6 flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4 text-white">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                <svg className="w-7 h-7 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <span className="font-bold text-lg">WhatsApp us & Unlock Exclusive Discounts</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-white/20 rounded animate-pulse"></div>
              <div className="w-6 h-6 bg-white/30 rounded animate-pulse delay-75"></div>
              <div className="w-6 h-6 bg-white/40 rounded animate-pulse delay-150"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Explore Learning Opportunities Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-900/30 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Explore Our Learning Opportunities
            </h2>
            <p className="text-white/70 max-w-3xl mx-auto">
              Register money mind. Expert level and any money. No worries, we can do anything. You can do and get anything. It's all done professionally.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Online Webinars Card */}
            <Card className="bg-gradient-to-br from-purple-800/50 to-purple-900/60 border-purple-600/40 backdrop-blur-sm p-8">
              <div className="mb-6">
                <div className="aspect-video bg-purple-700/30 rounded-lg mb-4 overflow-hidden">
                  <img src="/placeholder.svg" alt="Online Webinars" className="w-full h-full object-cover opacity-70" />
                </div>
              </div>
              <h3 className="text-white font-bold text-2xl mb-2">Online Webinars</h3>
              <p className="text-white/60 mb-6">Access our expert-led online training</p>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-[#FFD700] text-4xl font-bold">Rs.35,000</span>
                <span className="text-white/50 line-through">Rs.50,000</span>
              </div>
              <div className="flex gap-3">
                <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold flex-1 rounded-lg">
                  Get Started
                </Button>
                <Button variant="outline" className="border-2 border-white/30 text-white hover:bg-white/10 rounded-lg">
                  Learn More
                </Button>
              </div>
            </Card>

            {/* Online Resources Card */}
            <Card className="bg-gradient-to-br from-purple-800/50 to-purple-900/60 border-purple-600/40 backdrop-blur-sm p-8">
              <div className="mb-6">
                <div className="aspect-video bg-purple-700/30 rounded-lg mb-4 overflow-hidden">
                  <img src="/placeholder.svg" alt="Online Resources" className="w-full h-full object-cover opacity-70" />
                </div>
              </div>
              <h3 className="text-white font-bold text-2xl mb-2">Online Resources</h3>
              <p className="text-white/60 mb-6">Comprehensive learning materials</p>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-[#FFD700] text-4xl font-bold">Rs.5,000</span>
                <span className="text-white/50 line-through">Rs.8,000</span>
              </div>
              <div className="flex gap-3">
                <Button className="bg-[#FFD700] hover:bg-[#FFC700] text-black font-semibold flex-1 rounded-lg">
                  Get Started
                </Button>
                <Button variant="outline" className="border-2 border-white/30 text-white hover:bg-white/10 rounded-lg">
                  Learn More
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Upcoming Events & Competitions */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-[#FFD700]">UPCOMING EVENTS &</span>
              <br />
              <span className="text-white">COMPETITIONS</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Event Card 1 */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm overflow-hidden">
              <div className="aspect-video bg-purple-700/40 overflow-hidden">
                <img src="/placeholder.svg" alt="Event" className="w-full h-full object-cover opacity-70" />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full"></div>
                  <span className="text-white/70 text-sm">2024/10/19 at 9:00 am</span>
                </div>
                <h3 className="text-white font-semibold text-lg mb-3">BEST CRYPTO TRADER 2024 1st STAGE</h3>
                <p className="text-white/60 text-sm mb-4">Join our premier trading competition</p>
                <Button variant="outline" className="border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black w-full rounded-lg">
                  Register Now
                </Button>
              </div>
            </Card>

            {/* Event Card 2 */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm overflow-hidden">
              <div className="aspect-video bg-purple-700/40 overflow-hidden">
                <img src="/placeholder.svg" alt="Event" className="w-full h-full object-cover opacity-70" />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full"></div>
                  <span className="text-white/70 text-sm">2024/10/25 at 2:00 pm</span>
                </div>
                <h3 className="text-white font-semibold text-lg mb-3">WEBINAR CRYPTO MARKET ANALYSIS</h3>
                <p className="text-white/60 text-sm mb-4">Expert insights on market trends</p>
                <Button variant="outline" className="border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black w-full rounded-lg">
                  Register Now
                </Button>
              </div>
            </Card>

            {/* Event Card 3 */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm overflow-hidden">
              <div className="aspect-video bg-purple-700/40 overflow-hidden">
                <img src="/placeholder.svg" alt="Event" className="w-full h-full object-cover opacity-70" />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full"></div>
                  <span className="text-white/70 text-sm">2024/11/05 at 10:00 am</span>
                </div>
                <h3 className="text-white font-semibold text-lg mb-3">MEET EXPERT ONLINE AT 10AM</h3>
                <p className="text-white/60 text-sm mb-4">Q&A session with industry experts</p>
                <Button variant="outline" className="border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black w-full rounded-lg">
                  Register Now
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Student's Feedback Section */}
      <section id="feedback" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-900/30 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Student's Feedback
            </h2>
            <p className="text-white/70 max-w-3xl mx-auto">
              What are our customers say about their learning experience with us. Here some feedback.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card className="bg-gradient-to-br from-purple-800/60 to-purple-900/70 border-purple-600/40 backdrop-blur-sm p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-[#FFD700]" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                ))}
              </div>
              <p className="text-white/80 mb-6 italic">
                "Amazing experience! The instructors are knowledgeable and the course content is very practical. I've learned so much about crypto trading."
              </p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-purple-600 overflow-hidden">
                  <img src="/placeholder.svg" alt="Student" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="text-white font-semibold">Kasun Perera</p>
                  <p className="text-white/60 text-sm">Crypto Trader</p>
                </div>
              </div>
            </Card>

            {/* Testimonial 2 */}
            <Card className="bg-gradient-to-br from-purple-800/60 to-purple-900/70 border-purple-600/40 backdrop-blur-sm p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-[#FFD700]" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                ))}
              </div>
              <p className="text-white/80 mb-6 italic">
                "The best investment I made was in this course. The strategies taught here have helped me become a successful trader."
              </p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-purple-600 overflow-hidden">
                  <img src="/placeholder.svg" alt="Student" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="text-white font-semibold">Nimali Silva</p>
                  <p className="text-white/60 text-sm">Business Owner</p>
                </div>
              </div>
            </Card>

            {/* Testimonial 3 */}
            <Card className="bg-gradient-to-br from-purple-800/60 to-purple-900/70 border-purple-600/40 backdrop-blur-sm p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-[#FFD700]" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                ))}
              </div>
              <p className="text-white/80 mb-6 italic">
                "Excellent platform with great support. The community is very helpful and the resources are top-notch."
              </p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-purple-600 overflow-hidden">
                  <img src="/placeholder.svg" alt="Student" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="text-white font-semibold">Ravindu Fernando</p>
                  <p className="text-white/60 text-sm">Investor</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Contact
            </h2>
            <p className="text-white/70">
              Reach out our services to excel your journey with tech
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {/* Hours */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm p-6 text-center">
              <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-white font-bold text-xl mb-2">OUR HOURS</h3>
              <p className="text-white/70">Monday - Friday</p>
              <p className="text-white/70">9:00 AM - 6:00 PM</p>
            </Card>

            {/* Location */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm p-6 text-center">
              <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-white font-bold text-xl mb-2">LOCATION</h3>
              <p className="text-white/70">123 Business Street</p>
              <p className="text-white/70">Colombo, Sri Lanka</p>
            </Card>

            {/* Contact */}
            <Card className="bg-purple-900/40 border-purple-700/30 backdrop-blur-sm p-6 text-center">
              <div className="w-16 h-16 bg-[#FFD700] rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-white font-bold text-xl mb-2">CONTACT US</h3>
              <p className="text-white/70">+94 123 456 789</p>
              <p className="text-white/70">info@sbirth.com</p>
            </Card>
          </div>

          {/* Maps */}
          <div className="grid md:grid-cols-2 gap-8">
            <div className="aspect-video bg-purple-900/40 border border-purple-700/30 rounded-lg overflow-hidden">
              <img src="/placeholder.svg" alt="Map Location" className="w-full h-full object-cover opacity-70" />
            </div>
            <div className="aspect-video bg-purple-900/40 border border-purple-700/30 rounded-lg overflow-hidden">
              <img src="/placeholder.svg" alt="Map Location" className="w-full h-full object-cover opacity-70" />
            </div>
          </div>
        </div>
      </section>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/94123456789"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 z-50 w-16 h-16 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110"
      >
        <svg className="w-9 h-9 text-white" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>

      <Footer />
    </div>
  );
}
