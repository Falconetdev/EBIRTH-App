export default function Footer() {
  return (
    <footer className="bg-[#0a0015] border-t border-purple-900/30 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">sB</span>
              </div>
              <span className="text-white font-bold text-xl">sBirth</span>
            </div>
            <p className="text-white/60 text-sm">
              Building bridges for tomorrow's business leaders
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#who-we-are" className="text-white/60 hover:text-white text-sm transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
                  Courses
                </a>
              </li>
              <li>
                <a href="#contact" className="text-white/60 hover:text-white text-sm transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
                  Events
                </a>
              </li>
              <li>
                <a href="#feedback" className="text-white/60 hover:text-white text-sm transition-colors">
                  Testimonials
                </a>
              </li>
              <li>
                <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
                  Support
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li>Email: info@sbirth.com</li>
              <li>Phone: +94 123 456 789</li>
              <li>Address: Colombo, Sri Lanka</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-purple-900/30 mt-8 pt-8 text-center">
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} sBirth Business Academy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
